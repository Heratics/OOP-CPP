class point {
private:
    int x, y;
    
public: 
    point(int = 3, int = 4);
    
void print();    

~point();

};