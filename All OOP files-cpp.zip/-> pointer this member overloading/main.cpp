#include <iostream>

using namespace std;

class thisSign {
    int num;
public:
    thisSign(int j){ num = j; }
    
    void display(){
        cout << "num is: " << num << endl;
    }
    
    thisSign * operator->() { return this; }
};

int main(){
    int number;
    cout << "Enter the number to print: ";
    getline(cin, number);
    
    thisSign T(number);
    T.display(); // accessing display normally 
    
    thisSign * ptr = & T;
    ptr->display(); // using class pointer
    T->display(); // using overloaded operator

    return 0;
}