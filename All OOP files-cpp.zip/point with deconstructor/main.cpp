#include <iostream>
#include "point.h"

using namespace std;

int main()
{
    point p;
    point p1(9,8);

    return 0;
}